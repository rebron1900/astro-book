function o(e){return e.toLowerCase()}export{o as l};

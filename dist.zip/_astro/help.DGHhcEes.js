function t(e="",r="0 0 24 24",n="book-icon"){return`
    <svg viewBox="${r}" aria-hidden="true"${n?` class="${n}"`:""}>
        <use xlink:href="/icons.svg#${e}"></use>
    </svg>
    `}function o(e){try{let r;if(typeof e=="number"||/^\d+$/.test(e)){const n=typeof e=="number"?e:parseInt(e,10);r=new Date(n>999999999999?n:n*1e3)}else r=new Date(e);return isNaN(r.getTime())?(console.error("Invalid date format:",e),null):r.toISOString().split("T")[0]}catch(r){return console.error("Error normalizing date:",r),"1900-01-01"}}export{t as g,o as n};

import{_ as e}from"./tslib.rrx6G-_s.js";import{n as i}from"./no-case.CqyLDZWC.js";function s(a,r){return r===void 0&&(r={}),i(a,e({delimiter:"."},r))}export{s as d};

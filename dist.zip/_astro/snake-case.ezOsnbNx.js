import{_ as e}from"./tslib.rrx6G-_s.js";import{d as s}from"./dot-case.CpiCamLo.js";function t(a,r){return r===void 0&&(r={}),s(a,e({delimiter:"_"},r))}export{t as s};
